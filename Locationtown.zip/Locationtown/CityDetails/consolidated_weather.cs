﻿namespace CityDTO
{
    /// <summary>
    /// Class used to store weather details
    /// </summary>
    public class consolidated_weather
    {
        public string created { get; set; }

        public string min_temp { get; set; }
        public string predictability { get; set; }
    }
}