﻿using Newtonsoft.Json;
using System;

namespace CityDTO
{
    /// <summary>
    /// Used to display weather details in api
    /// </summary>
    public class WeatherDTO
    {
        [JsonProperty(propertyName:"Name")]
        public string title { get; set; }

        [JsonProperty(propertyName: "Created_Datetime")]
        public string created { get; set; }

        [JsonProperty(propertyName: "Min_Temperature")]
        public float min_temp { get; set; }

        [JsonProperty(propertyName: "Predictability")]
        public int predictability { get; set; }
    }
}
