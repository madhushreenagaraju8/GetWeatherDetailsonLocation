﻿using System.Collections.Generic;


namespace CityDTO
{
    /// <summary>
    /// Class used to store name and woeid based on location
    /// </summary>
    public class Woeid
    {
        public string title { get; set; }

        public string woeid { get; set; }

    }

    /// <summary>
    /// Class stores weather details based on woeid
    /// </summary>
    public class WeatherWoeid
    {
        public List<consolidated_weather> consolidated_weather { get; set; }
       

    }
}
