﻿
namespace MetaWeatherBusiness.Interfaces
{
    public interface IWeatherdetails
    {
        string GetWeatherdata(string strLocation);
    }
}
