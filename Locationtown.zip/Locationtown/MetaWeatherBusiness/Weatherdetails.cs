﻿using System;
using System.Collections.Generic;
using System.Linq;
using MetaWeatherBusiness.Interfaces;
using RestSharp;
using CityDTO;
using Newtonsoft.Json;

namespace MetaWeatherBusiness
{
    public class Weatherdetails: IWeatherdetails
    {

        #region Public functions
        /// <summary>
        /// Returns the response of weather details in json format
        /// </summary>
        /// <param name="strLocation"></param>
        /// <returns></returns>
        public string GetWeatherdata(string strLocation)
        {
            try
            {
                WeatherDTO ObjweatherDTO;
                List<WeatherDTO> lstWeatherDTOs = new List<WeatherDTO>();

                var response = URLresponse<List<Woeid>>("https://www.metaweather.com/api/location/search/?query=" + strLocation);
                foreach (var eachLocation in response.Data)
                {
                    ObjweatherDTO = new WeatherDTO
                    {
                        title = eachLocation.title
                    };
                    GetRecentWeather(eachLocation.woeid, ObjweatherDTO);
                    lstWeatherDTOs.Add(ObjweatherDTO);
                }

                string strserialize = JsonConvert.SerializeObject(lstWeatherDTOs);
                return strserialize;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion


        #region Private Functions
        /// <summary>
        /// Get the response from URL and convert the response based on generic type T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="strUrl"></param>
        /// <returns></returns>
        private IRestResponse<T> URLresponse<T>(string strUrl)
        {
            try
            {
                var client = new RestClient(strUrl);
                return client.Execute<T>(new RestRequest());
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }


        /// <summary>
        /// Retrieves weather details based on woeid
        /// </summary>
        /// <param name="strWoeid"></param>
        /// <param name="weatherDTO"></param>
        private void GetRecentWeather(string strWoeid,WeatherDTO weatherDTO)
        {
            try
            {
                var response = URLresponse<WeatherWoeid>("https://www.metaweather.com/api/location/" + strWoeid);

                var con_data = response.Data.consolidated_weather.Where(s => s.created == response.Data.consolidated_weather.Max(x => x.created))
                            .FirstOrDefault();
                weatherDTO.created = con_data.created;
                weatherDTO.min_temp = float.Parse(con_data.min_temp);
                weatherDTO.predictability = Convert.ToInt32(con_data.predictability);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion
    }
}
