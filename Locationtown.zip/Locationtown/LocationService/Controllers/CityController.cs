﻿using Microsoft.AspNetCore.Mvc;
using MetaWeatherBusiness.Interfaces;
using MetaWeatherBusiness;
using System;

namespace LocationService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        #region Global variables
        private readonly IWeatherdetails objWeatherdetails;
        #endregion

        /// <summary>
        /// Constructor to create instance of business class
        /// </summary>
        public CityController()
        {
            objWeatherdetails = new Weatherdetails();
        }

        #region Get Actions
        /// <summary>
        /// GET action. URL : api/city
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public string Get()
        {
            return "Enter location name in the URL to get weather details";
        }

        /// <summary>
        /// GET action. URL : api/city/{location}
        /// </summary>
        /// <param name="strLocation"></param>
        /// <returns></returns>
        [HttpGet("{strLocation:alpha}", Name = "GetLocation")]
        public string GetLocation(string strLocation)
        {
            try
            {
                var data = objWeatherdetails.GetWeatherdata(strLocation);
                return data;
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion


    }
}
