﻿using Xunit;
using MetaWeatherBusiness;

namespace LocationService.Test
{
    public class MetaWeatherBusinessTest
    {
        private readonly Weatherdetails objWeatherdetails;
        public MetaWeatherBusinessTest()
        {
            objWeatherdetails = new Weatherdetails();
        }

        [Fact]
        public void GetWeatherdataTest()
        {
            var test = objWeatherdetails.GetWeatherdata("Atlanta");
            Assert.IsType<string>(test);
        }

        [Fact]
        public void GetWeatherdataTest1()
        {
            var test = objWeatherdetails.GetWeatherdata("Atlanta");
            Assert.IsNotType<int>(test);
        }
    }
}
