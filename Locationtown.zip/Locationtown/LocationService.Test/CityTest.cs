using Xunit;
using LocationService.Controllers;

namespace LocationService.Test
{
    public class CityTest
    {
        private readonly CityController ObjCityController;

        public CityTest()
        {
            ObjCityController = new CityController();
        }

        [Fact]
        public void GetTest()
        {
            var test=ObjCityController.Get();
            Assert.IsType<string>(test);
        }

        [Fact]
        public void GetTest1()
        {
            var test = ObjCityController.Get();
            Assert.IsNotType<int>(test);
        }

        [Fact]
        public void GetTest2()
        {
            var test = ObjCityController.Get();
            Assert.Equal("Enter location name in the URL to get weather details",test);
        }

        [Fact]
        public void GetTest3()
        {
            var test = ObjCityController.Get();
            Assert.NotEqual("Not pass", test);
        }

        [Fact]
        public void GetTestbyLocation()
        {
            var test = ObjCityController.GetLocation("Atlanta");
            Assert.IsType<string>(test);
        }

        [Fact]
        public void GetTestbyLocation1()
        {
            var test = ObjCityController.GetLocation("Atlanta");
            Assert.IsNotType<int>(test);
        }
    }
}
